// Variable Identifier
const exampleDeclaration = document.getElementById("placeIdHere");

// Function Declaration
function ExampleFunctionName(params) {}
